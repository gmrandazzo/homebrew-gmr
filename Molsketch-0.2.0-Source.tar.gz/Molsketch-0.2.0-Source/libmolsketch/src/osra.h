namespace Molsketch {
  
  Molecule*  call_osra(QString fileName);

}

